const cursor = document.querySelector('.custom-cursor');

document.addEventListener('mousemove', (e) => {
  cursor.style.transform = `translate(${e.clientX}px, ${e.clientY}px)`;
});

cursor.addEventListener('click', () => {
  const scream = new Audio('https://freesound.org/data/previews/341/341695_3248244-lq.mp3');
  scream.play();
});